import { useMemo, useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, CheckCircle2, Download, Loader2 } from "lucide-react";
import jsPDF from "jspdf";

type Domain = "fisico" | "cognitivo" | "psicossocial";

interface MfisItem {
  numero: number;
  texto: string;
  dominio: Domain;
}

const OPCOES = [
  { valor: 0, label: "Nunca" },
  { valor: 1, label: "Raro" },
  { valor: 2, label: "Poucas vezes" },
  { valor: 3, label: "Muitas vezes" },
  { valor: 4, label: "Sempre" },
];

// Escala Modificada do Impacto da Fadiga (MFIS) - versão brasileira validada
// PAVAN, K. et al. Esclerose múltipla: adaptação transcultural e validação da
// escala modificada de impacto de fadiga. Arq. Neuro-Psiquiatr., vol. 65, p. 669-673, 2007.
const ITENS: MfisItem[] = [
  { numero: 1, texto: "Eu tenho estado menos atento(a)", dominio: "cognitivo" },
  { numero: 2, texto: "Eu tenho tido dificuldades de prestar atenção por longos períodos", dominio: "cognitivo" },
  { numero: 3, texto: "Eu tenho sido incapaz de pensar claramente", dominio: "cognitivo" },
  { numero: 4, texto: "Eu tenho sido desajeitado e descoordenado", dominio: "fisico" },
  { numero: 5, texto: "Eu tenho estado esquecido", dominio: "cognitivo" },
  { numero: 6, texto: "Eu tenho tido que me adequar nas minhas atividades físicas", dominio: "fisico" },
  {
    numero: 7,
    texto: "Eu tenho estado menos motivado para fazer qualquer coisa que requer esforço físico",
    dominio: "fisico",
  },
  {
    numero: 8,
    texto: "Eu tenho estado menos motivado para participar de atividades sociais",
    dominio: "psicossocial",
  },
  {
    numero: 9,
    texto: "Eu tenho estado limitado nas minhas habilidades para fazer coisas fora de casa",
    dominio: "psicossocial",
  },
  { numero: 10, texto: "Eu tenho dificuldades em manter esforço físico por longos períodos", dominio: "fisico" },
  { numero: 11, texto: "Eu tenho tido dificuldades em tomar decisões", dominio: "cognitivo" },
  { numero: 12, texto: "Eu tenho estado menos motivado para fazer algo que requer pensar", dominio: "cognitivo" },
  { numero: 13, texto: "Meus músculos têm sentido fraqueza", dominio: "fisico" },
  { numero: 14, texto: "Eu tenho estado fisicamente desconfortável", dominio: "fisico" },
  {
    numero: 15,
    texto: "Eu tenho tido dificuldades em terminar tarefas que requerem esforço de pensar",
    dominio: "cognitivo",
  },
  {
    numero: 16,
    texto: "Eu tenho tido dificuldades em organizar meus pensamentos quando estou fazendo coisas em casa ou no trabalho",
    dominio: "cognitivo",
  },
  {
    numero: 17,
    texto: "Eu tenho estado menos capaz de completar tarefas que requerem esforço físico",
    dominio: "fisico",
  },
  { numero: 18, texto: "Meu pensamento tem estado mais lento", dominio: "cognitivo" },
  { numero: 19, texto: "Eu tenho tido dificuldades em concentração", dominio: "cognitivo" },
  { numero: 20, texto: "Eu tenho limitação nas minhas atividades físicas", dominio: "fisico" },
  {
    numero: 21,
    texto: "Eu tenho precisado descansar com mais frequência ou por longos períodos",
    dominio: "fisico",
  },
];

const DOMINIO_LABEL: Record<Domain, string> = {
  fisico: "Físico",
  cognitivo: "Cognitivo",
  psicossocial: "Psicossocial",
};

const DOMINIO_MAX: Record<Domain, number> = {
  fisico: 36,
  cognitivo: 40,
  psicossocial: 8,
};

const PONTO_DE_CORTE = 38;

type Step = "dados" | "questionario" | "resultado";

export default function CalculadoraMFIS() {
  const [step, setStep] = useState<Step>("dados");
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [respostas, setRespostas] = useState<Record<number, number | undefined>>({});
  const [gerandoPdf, setGerandoPdf] = useState(false);

  const emailValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const dadosValidos = nome.trim().length >= 2 && emailValido;

  const totalRespondido = ITENS.filter((item) => respostas[item.numero] !== undefined).length;
  const questionarioCompleto = totalRespondido === ITENS.length;

  const resultado = useMemo(() => {
    const somaDominio: Record<Domain, number> = { fisico: 0, cognitivo: 0, psicossocial: 0 };
    for (const item of ITENS) {
      somaDominio[item.dominio] += respostas[item.numero] ?? 0;
    }
    const total = somaDominio.fisico + somaDominio.cognitivo + somaDominio.psicossocial;
    return { somaDominio, total };
  }, [respostas]);

  const dataAvaliacao = useMemo(
    () => new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" }),
    []
  );

  const handleResponder = (numero: number, valor: number) => {
    setRespostas((prev) => ({ ...prev, [numero]: valor }));
  };

  const gerarPdf = async () => {
    setGerandoPdf(true);
    try {
      const doc = new jsPDF({ unit: "mm", format: "a4" });
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const marginX = 18;
      const contentWidth = pageWidth - marginX * 2;
      let y = 20;

      const ensureSpace = (needed: number) => {
        if (y + needed > pageHeight - 18) {
          doc.addPage();
          y = 20;
        }
      };

      // Cabeçalho
      doc.setFont("helvetica", "bold");
      doc.setFontSize(16);
      doc.text("ConectaFisio", marginX, y);
      doc.setFontSize(12);
      doc.text("Escala Modificada do Impacto da Fadiga (MFIS)", pageWidth - marginX, y, { align: "right" });
      y += 5;
      doc.setDrawColor(180);
      doc.line(marginX, y, pageWidth - marginX, y);
      y += 8;

      // Dados do respondente
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      doc.text(`Nome: ${nome}`, marginX, y);
      y += 6;
      doc.text(`E-mail: ${email}`, marginX, y);
      y += 6;
      doc.text(`Data da avaliação: ${dataAvaliacao}`, marginX, y);
      y += 10;

      // Orientações
      doc.setFont("helvetica", "italic");
      doc.setFontSize(9);
      const orientacoes =
        "Respostas referentes à frequência com que a fadiga afetou o respondente nas quatro últimas semanas " +
        "(0 = Nunca, 1 = Raro, 2 = Poucas vezes, 3 = Muitas vezes, 4 = Sempre).";
      const orientacoesLinhas = doc.splitTextToSize(orientacoes, contentWidth);
      doc.text(orientacoesLinhas, marginX, y);
      y += orientacoesLinhas.length * 4 + 6;

      // Itens
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      for (const item of ITENS) {
        const valor = respostas[item.numero] ?? 0;
        const opcao = OPCOES.find((o) => o.valor === valor)!;
        const textoItem = `${item.numero}. ${item.texto}`;
        const linhas = doc.splitTextToSize(textoItem, contentWidth - 42);
        const alturaBloco = Math.max(linhas.length * 4.2, 6) + 3;
        ensureSpace(alturaBloco);

        doc.setFont("helvetica", "normal");
        doc.text(linhas, marginX, y);

        doc.setFont("helvetica", "bold");
        doc.setFillColor(230, 238, 250);
        doc.roundedRect(pageWidth - marginX - 36, y - 4.2, 36, 6.5, 1, 1, "F");
        doc.text(`${valor} - ${opcao.label}`, pageWidth - marginX - 18, y, { align: "center" });

        y += alturaBloco;
      }

      y += 4;
      ensureSpace(40);
      doc.setDrawColor(180);
      doc.line(marginX, y, pageWidth - marginX, y);
      y += 8;

      // Resultado por domínio
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("Resultado", marginX, y);
      y += 7;

      doc.setFontSize(10);
      const linhasDominio: [string, number, number][] = [
        [DOMINIO_LABEL.fisico, resultado.somaDominio.fisico, DOMINIO_MAX.fisico],
        [DOMINIO_LABEL.cognitivo, resultado.somaDominio.cognitivo, DOMINIO_MAX.cognitivo],
        [DOMINIO_LABEL.psicossocial, resultado.somaDominio.psicossocial, DOMINIO_MAX.psicossocial],
      ];
      for (const [label, valor, max] of linhasDominio) {
        doc.setFont("helvetica", "normal");
        doc.text(`Domínio ${label}:`, marginX, y);
        doc.setFont("helvetica", "bold");
        doc.text(`${valor} / ${max}`, marginX + 60, y);
        y += 6;
      }

      y += 2;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.text("Escore total MFIS:", marginX, y);
      doc.text(`${resultado.total} / 84`, marginX + 60, y);
      y += 9;

      const temFadiga = resultado.total >= PONTO_DE_CORTE;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      const interpretacao = temFadiga
        ? `Escore igual ou acima do ponto de corte (${PONTO_DE_CORTE}): compatível com presença de fadiga. Quanto maior o escore, maior o grau de fadiga relatado.`
        : `Escore abaixo do ponto de corte (${PONTO_DE_CORTE}): compatível com ausência de fadiga significativa.`;
      const interpretacaoLinhas = doc.splitTextToSize(interpretacao, contentWidth);
      ensureSpace(interpretacaoLinhas.length * 5 + 10);
      doc.text(interpretacaoLinhas, marginX, y);
      y += interpretacaoLinhas.length * 5 + 8;

      // Rodapé / fonte
      ensureSpace(20);
      doc.setFont("helvetica", "italic");
      doc.setFontSize(7.5);
      const fonte =
        "Fonte: PAVAN, K., SCHMIDT, K., MARANGONI, B., MENDES, M.F., TILBERY, C.P., LIANZA, S. Esclerose " +
        "múltipla: adaptação transcultural e validação da escala modificada de impacto de fadiga. Arq. Neuro-Psiquiatr., " +
        "vol. 65, p. 669-673, 2007.";
      const fonteLinhas = doc.splitTextToSize(fonte, contentWidth);
      doc.text(fonteLinhas, marginX, y);
      y += fonteLinhas.length * 3.5 + 4;
      doc.text(
        "Documento gerado automaticamente pela calculadora MFIS do ConectaFisio como ferramenta de apoio. " +
          "Não substitui a avaliação clínica presencial de um profissional habilitado.",
        marginX,
        y
      );

      const nomeArquivo = `MFIS_${nome.trim().replace(/\s+/g, "_")}_${dataAvaliacao.replace(/\//g, "-")}.pdf`;
      doc.save(nomeArquivo);
    } finally {
      setGerandoPdf(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="mx-auto w-full max-w-3xl">
        <Link
          href="/"
          className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
        </Link>

        <div className="text-center mb-8">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">
            Calculadora MFIS - Escala Modificada do Impacto da Fadiga
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            Instrumento validado para avaliação do impacto da fadiga nos domínios físico, cognitivo e
            psicossocial.
          </p>
        </div>

        {step === "dados" && (
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle>Identificação</CardTitle>
              <CardDescription>
                Informe seu nome e e-mail para gerar, ao final, um PDF com o resultado preenchido.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="nome">Nome completo</Label>
                <Input
                  id="nome"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Digite seu nome completo"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="email">E-mail</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seuemail@exemplo.com"
                />
                {email.length > 0 && !emailValido && (
                  <p className="text-xs text-red-600">Informe um e-mail válido.</p>
                )}
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-xs text-blue-900">
                  Nas quatro últimas semanas, considere com que frequência a fadiga afetou cada uma das 21
                  situações a seguir.
                </p>
              </div>
              <Button className="w-full" disabled={!dadosValidos} onClick={() => setStep("questionario")}>
                Iniciar Questionário
              </Button>
            </CardContent>
          </Card>
        )}

        {step === "questionario" && (
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle>Questionário MFIS</CardTitle>
              <CardDescription>
                Por causa da minha fadiga, nas quatro últimas semanas: ({totalRespondido}/{ITENS.length}{" "}
                respondidas)
              </CardDescription>
              <div className="w-full h-1.5 bg-gray-200 rounded-full mt-2">
                <div
                  className="h-1.5 bg-blue-600 rounded-full transition-all"
                  style={{ width: `${(totalRespondido / ITENS.length) * 100}%` }}
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {ITENS.map((item) => (
                <div key={item.numero} className="border-b border-gray-100 pb-4 last:border-0">
                  <p className="text-sm font-medium text-gray-900 mb-3">
                    {item.numero}. {item.texto}
                  </p>
                  <div className="grid grid-cols-5 gap-1.5">
                    {OPCOES.map((opcao) => (
                      <button
                        key={opcao.valor}
                        type="button"
                        onClick={() => handleResponder(item.numero, opcao.valor)}
                        className={`text-xs sm:text-sm py-2 px-1 rounded-lg border-2 font-medium transition-all ${
                          respostas[item.numero] === opcao.valor
                            ? "border-blue-600 bg-blue-50 text-blue-700"
                            : "border-gray-200 bg-white text-gray-600 hover:border-gray-300"
                        }`}
                      >
                        <span className="block font-bold">{opcao.valor}</span>
                        <span className="block leading-tight">{opcao.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              ))}

              <div className="flex gap-3 pt-2">
                <Button type="button" variant="outline" className="flex-1" onClick={() => setStep("dados")}>
                  Voltar
                </Button>
                <Button
                  type="button"
                  className="flex-1"
                  disabled={!questionarioCompleto}
                  onClick={() => setStep("resultado")}
                >
                  Ver Resultado
                </Button>
              </div>
              {!questionarioCompleto && (
                <p className="text-xs text-gray-500 text-center">
                  Responda todos os 21 itens para calcular o resultado.
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {step === "resultado" && (
          <Card className="shadow-xl">
            <CardHeader>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-6 w-6 text-green-500" />
                <CardTitle>Resultado</CardTitle>
              </div>
              <CardDescription>
                {nome} • {email} • {dataAvaliacao}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-center">
                  <p className="text-xs text-gray-500 mb-1">Físico</p>
                  <p className="text-2xl font-bold text-gray-900">{resultado.somaDominio.fisico}</p>
                  <p className="text-xs text-gray-500">/ {DOMINIO_MAX.fisico}</p>
                </div>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-center">
                  <p className="text-xs text-gray-500 mb-1">Cognitivo</p>
                  <p className="text-2xl font-bold text-gray-900">{resultado.somaDominio.cognitivo}</p>
                  <p className="text-xs text-gray-500">/ {DOMINIO_MAX.cognitivo}</p>
                </div>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-center">
                  <p className="text-xs text-gray-500 mb-1">Psicossocial</p>
                  <p className="text-2xl font-bold text-gray-900">{resultado.somaDominio.psicossocial}</p>
                  <p className="text-xs text-gray-500">/ {DOMINIO_MAX.psicossocial}</p>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-5 text-center">
                <p className="text-sm text-blue-900 mb-1">Escore Total MFIS</p>
                <p className="text-4xl font-extrabold text-blue-900">{resultado.total}</p>
                <p className="text-xs text-blue-800">de 84 pontos possíveis</p>
              </div>

              <div
                className={`rounded-lg p-4 border ${
                  resultado.total >= PONTO_DE_CORTE
                    ? "bg-amber-50 border-amber-200"
                    : "bg-green-50 border-green-200"
                }`}
              >
                <p
                  className={`text-sm font-medium ${
                    resultado.total >= PONTO_DE_CORTE ? "text-amber-900" : "text-green-900"
                  }`}
                >
                  {resultado.total >= PONTO_DE_CORTE
                    ? `Escore ≥ ${PONTO_DE_CORTE}: compatível com presença de fadiga.`
                    : `Escore < ${PONTO_DE_CORTE}: compatível com ausência de fadiga significativa.`}
                </p>
                <p className="text-xs mt-1 text-gray-600">
                  Quanto maior o escore, maior o grau de fadiga relatado. Este resultado é uma ferramenta de
                  apoio e não substitui a avaliação clínica de um profissional habilitado.
                </p>
              </div>

              <Button className="w-full" onClick={gerarPdf} disabled={gerandoPdf}>
                {gerandoPdf ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Download className="mr-2 h-4 w-4" />
                )}
                Baixar PDF com o resultado
              </Button>

              <div className="flex gap-3">
                <Button type="button" variant="outline" className="flex-1" onClick={() => setStep("questionario")}>
                  Revisar Respostas
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  className="flex-1"
                  onClick={() => {
                    setRespostas({});
                    setStep("dados");
                    setNome("");
                    setEmail("");
                  }}
                >
                  Nova Avaliação
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
